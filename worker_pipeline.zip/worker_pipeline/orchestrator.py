"""
Orchestrator — dispatches every segment in a Storyboard to the right renderer,
retries a failing segment once, and degrades to a held frame from the nearest
earlier rendered segment if it still fails, so one bad segment never sinks the
whole lesson.

Retry/degrade policy (formalizes the design discussion from planning):
  - Any segment type: retry the whole render() call once (MAX_RENDER_ATTEMPTS=2
    total attempts). This is a *failure* retry (API/network/ffmpeg errors) —
    distinct from image_renderer's own internal *quality* retry (low critic
    score), which already happened inside a single render() call.
  - video: Sprint 3's VideoRenderer already demotes Veo failures to image
    internally without raising. Orchestrator-level retry only engages if
    *both* Veo and that internal image demotion fail. On the second attempt,
    the renderer is re-looked-up by the segment's CURRENT type (see
    _render_with_degrade) rather than reusing the original video_renderer —
    otherwise a retry would re-attempt the expensive Veo call a second time
    even though attempt 1 already gave up on it and moved to image.
  - Any type, after exhausting retries: hold the nearest earlier rendered
    segment's last frame, re-narrated with this segment's OWN narration_text
    (via tts.py) so the viewer still hears what was meant to be said even
    though the intended visual failed, for the real spoken duration.
  - Edge case, deliberately NOT papered over: if the failing segment is first
    in the lesson (or every earlier segment also failed), there is no real
    frame to hold. Rather than fabricate a blank placeholder — which would
    violate the same "never invent an asset" discipline the URL guard
    enforces — this raises, surfacing the failure instead of silently
    shipping a broken lesson.
  - TTS is the one true hard-fail case (per the plan), and this falls out
    naturally rather than needing special-case code: the held-frame degrade
    path above ALSO calls tts.generate_narration_audio(). If Azure Speech is
    genuinely down, that call fails too, so the degrade path fails right
    along with the primary render, and the failure correctly propagates
    instead of shipping a mute segment.
"""
import logging
import os
import subprocess
import tempfile
import uuid
from typing import Callable, Dict, List, Optional

import requests

from . import tts
from .asset_manifest import compute_prompt_hash, register_asset
from .renderers.base import Renderer
from .renderers.image_renderer import ImageRenderer, make_ken_burns_clip
from .renderers.manim_renderer import ManimRenderer
from .renderers.video_renderer import VideoRenderer
from .schema import Segment, Storyboard

logger = logging.getLogger(__name__)

MAX_RENDER_ATTEMPTS = 2


def _build_reference_resolver(storyboard: Storyboard) -> Callable[[str], Optional[str]]:
    by_id = {s.id: s for s in storyboard.segments}

    def resolve(segment_id: str) -> Optional[str]:
        seg = by_id.get(segment_id)
        return seg.source_asset_url if seg else None

    return resolve


def extract_last_frame(clip_url: str, output_path: str, work_dir: str) -> None:
    """Downloads clip_url and grabs its last frame, mirroring
    learnai/worker.py's generate_thumbnail() (-sseof -1 ... -frames:v 1)."""
    local_clip = os.path.join(work_dir, f"_ref_{uuid.uuid4().hex}.mp4")
    resp = requests.get(clip_url, timeout=60)
    resp.raise_for_status()
    with open(local_clip, "wb") as f:
        f.write(resp.content)

    cmd = ["ffmpeg", "-y", "-sseof", "-1", "-i", local_clip, "-frames:v", "1", output_path]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
    except FileNotFoundError:
        raise RuntimeError("ffmpeg not found on PATH — required to extract a held frame")
    if result.returncode != 0:
        raise RuntimeError(f"Failed to extract last frame:\n{result.stderr[-500:]}")
    if not os.path.exists(output_path) or os.path.getsize(output_path) == 0:
        raise RuntimeError("Extracted frame is missing or empty")


def _degrade_to_held_frame(
    segment: Segment, ordered_segments: List[Segment], work_dir: str, cause: Exception
) -> None:
    prior_rendered = [
        s for s in ordered_segments
        if s.order < segment.order and s.clip_url and s.status == "rendered"
    ]
    if not prior_rendered:
        raise RuntimeError(
            f"Segment {segment.id} failed after {MAX_RENDER_ATTEMPTS} attempts and has no "
            "earlier rendered segment to hold a frame from (it's first in the lesson, or every "
            f"earlier segment also failed) — cannot degrade further. Original error: {cause}"
        )
    reference_segment = prior_rendered[-1]  # closest earlier rendered segment

    frame_path = os.path.join(work_dir, f"{segment.id}_held_frame.png")
    extract_last_frame(reference_segment.clip_url, frame_path, work_dir)

    # The narration is the important part here, arguably more than the held
    # visual — a viewer should still hear what this segment was meant to say
    # even though its own visual failed. This also gives TTS the "hard-fail"
    # property described in tts.py's docstring: if Azure Speech is genuinely
    # down, this call fails too and the whole degrade path fails with it,
    # propagating instead of silently shipping a mute segment.
    prompt_hash = compute_prompt_hash(f"held-frame-from-{reference_segment.id}", "", segment.subject_area)
    audio_path = os.path.join(work_dir, f"{segment.id}_held_narration.wav")
    tts.generate_narration_audio(segment.narration_text, audio_path)
    narration_duration = tts.get_media_duration(audio_path)

    silent_clip_path = os.path.join(work_dir, f"{segment.id}_held_silent.mp4")
    make_ken_burns_clip(frame_path, narration_duration, silent_clip_path, segment.aspect_ratio)

    clip_path = os.path.join(work_dir, f"{segment.id}_held.mp4")
    tts.mux_audio_onto_video(silent_clip_path, audio_path, clip_path)
    clip_ref = register_asset(clip_path, segment.id, "held_frame_clip", prompt_hash)

    segment.clip_url = clip_ref.url
    segment.actual_duration_seconds = narration_duration
    segment.status = "rendered"
    segment.error_message = (
        f"Degraded: held frame from {reference_segment.id} after exhausting retries ({cause})"
    )[:500]
    logger.info(f"[orchestrator] segment {segment.id} degraded to held frame from {reference_segment.id}")


def _render_with_degrade(
    renderers: Dict[str, Renderer], segment: Segment, ordered_segments: List[Segment], work_dir: str
) -> None:
    last_exc: Optional[Exception] = None
    for attempt in range(1, MAX_RENDER_ATTEMPTS + 1):
        # Re-look-up by CURRENT type each attempt, not the type dispatched at
        # attempt 1 — a video segment that already demoted itself to image
        # internally (Sprint 3) must not re-attempt the expensive Veo call
        # on retry just because it was originally dispatched as "video".
        renderer = renderers[segment.type]
        try:
            renderer.render(segment)
            return
        except Exception as exc:
            last_exc = exc
            logger.warning(
                f"[orchestrator] segment {segment.id} attempt {attempt}/{MAX_RENDER_ATTEMPTS} failed: {exc}"
            )

    logger.warning(
        f"[orchestrator] segment {segment.id} exhausted {MAX_RENDER_ATTEMPTS} attempts — degrading"
    )
    _degrade_to_held_frame(segment, ordered_segments, work_dir, last_exc)


def render_storyboard(
    storyboard: Storyboard,
    work_dir: Optional[str] = None,
    renderers: Optional[Dict[str, Renderer]] = None,
) -> Storyboard:
    """
    Render every segment in a Storyboard, in order, applying the retry +
    degrade policy above. Mutates and returns the same Storyboard — segments
    are mutated in place by each renderer's render(), per the Renderer
    contract (base.py).

    `renderers` is injectable (segment type -> Renderer) so tests can supply
    fakes without needing real API keys/Docker; defaults to the real
    Manim/Image/Video renderers wired together with a live reference resolver.
    """
    work_dir = work_dir or tempfile.mkdtemp(prefix="orchestrator_")
    os.makedirs(work_dir, exist_ok=True)

    if renderers is None:
        resolve_reference = _build_reference_resolver(storyboard)
        image_renderer = ImageRenderer(resolve_reference=resolve_reference, work_dir=work_dir)
        renderers = {
            "manim": ManimRenderer(work_dir=work_dir),
            "image": image_renderer,
            "video": VideoRenderer(image_renderer=image_renderer, work_dir=work_dir),
        }

    ordered = sorted(storyboard.segments, key=lambda s: s.order)
    for segment in ordered:
        _render_with_degrade(renderers, segment, ordered, work_dir)

    return storyboard
